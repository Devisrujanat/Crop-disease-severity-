import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
public class Symptoms extends javax.swing.JFrame {
    public Symptoms() {
        initComponents();
    }
    private void initComponents() {

        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();

        jButton4.setText("jButton4");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24));
        jLabel1.setText("Symptoms");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 134, -1));

        jLabel2.setText("Crop_ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 64, -1, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 55, 445, 34));

        jLabel3.setText("High:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 122, 45, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 101, 445, 58));

        jLabel4.setText("Low:");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 189, -1, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 171, 445, 59));

        jLabel5.setText("Medium:");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(42, 231, -1, -1));
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 242, 445, 58));

        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(627, 119, -1, -1));

        jButton2.setText("Modify");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(627, 234, -1, -1));

        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(779, 234, -1, -1));

        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 542, -1, -1));

        jButton6.setText("View");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(779, 119, -1, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); 
        jLabel6.setText("Symptoms Table View");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 306, -1, -1));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Crop_ID", "High", "Low", "Medium"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(99, 337, -1, 186));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images (1).jpg"))); 
        jLabel7.setText("jLabel7");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 610));

        pack();
    }
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        dispose();
    }
   private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try 
	  {
              DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
                Connection con = (Connection) DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE" ,"srujana","vasavi");
   
                Statement statement = con.createStatement();
               String query = "INSERT INTO symptoms values("+"'"+jTextField1.getText()+"' , "+"'"+jTextField2.getText()+"', "+"'"+ jTextField3.getText()+"', "+"'"+ jTextField4.getText()+"')";
                ResultSet rs = statement.executeQuery(query);
                
                JOptionPane.showMessageDialog(new JFrame(), "Inserted Successfully", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
           } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  
     
    }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
          try 
	  {
               if(jTable1.getRowCount()==0)
              {
             JOptionPane.showMessageDialog(this, "Please View the table to Update", "Notice", JOptionPane.INFORMATION_MESSAGE);

              }
              
              else
              {
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select single Row from View table to Update", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {
              DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
         
               Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE" ,"srujana","vasavi");
                Statement statement = con.createStatement();
                 String query = "UPDATE symptoms SET high=" +"'"+ jTextField2.getText() +"',low=" +"'"+ jTextField3.getText() +"',  medium ="+" '"+ jTextField4.getText() +"' WHERE ID =+" + jTextField1.getText();
                 
                ResultSet rs = statement.executeQuery(query);
                
                JOptionPane.showMessageDialog(new JFrame(), "Updated Successfully", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
              

      } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }

    }
   private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
         try 
	  {
              if(jTable1.getRowCount()==0)
              {
             JOptionPane.showMessageDialog(this, "Please View the table to Delete", "Notice", JOptionPane.INFORMATION_MESSAGE);

              }
              
              else
              {
              int r = jTable1.getSelectedRow();
              
              if(r<0)
              {
                  JOptionPane.showMessageDialog(this, "Please select single Row from view table to Delete", "Notice", JOptionPane.INFORMATION_MESSAGE);
              }
              
              else
              {
              DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE" ,"srujana","vasavi");
   
                Statement statement = con.createStatement();
                String query = "DELETE from symptoms where id =  '" + jTextField1.getText() + "'"; 
                ResultSet rs = statement.executeQuery(query);
                
                JOptionPane.showMessageDialog(new JFrame(), "Deleted Successfully", "INFORMATION", JOptionPane.INFORMATION_MESSAGE);
                rs.close();
                statement.close();
                con.close();
              }
              }
              

      } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
    }

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {
        try 
	  {
              DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
               Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE" ,"srujana","vasavi");
                Statement statement = con.createStatements();
                String query = "SELECT * FROM symptoms";
                ResultSet rs = statement.executeQuery(query);
                DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
                 model.setRowCount(0);
                
                while(rs.next()) 
                {                      
                    model.addRow(new Object[]{ rs.getString("ID"), rs.getString("High"),rs.getString("Low"),rs.getString("Medium") });
                }
                rs.close();
                statement.close();
                con.close();
                
              

      } 
	  
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
                                       

    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Symptoms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Symptoms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Symptoms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Symptoms.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Symptoms().setVisible(true);
            }
        });
    }
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
}
